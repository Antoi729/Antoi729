# Collecte — application web

Application Flask de formulaires de collecte **transparente et avec consentement**. Elle inclut :
- création de liens publics non devinables ;
- explication de la finalité et du destinataire avant le formulaire ;
- consentement obligatoire et horodaté ;
- stockage SQLite (ou base PostgreSQL via `DATABASE_URL`) ;
- espace administrateur protégé par identifiant et hash de mot de passe ;
- statistiques de visites et réponses ;
- export CSV et suppression des réponses ;
- notifications e-mail facultatives ;
- protection CSRF et limitation des tentatives.

## Installation locale

Python 3.10+ recommandé.

```bash
python -m venv .venv
# Windows : .venv\Scripts\activate
# macOS/Linux :
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

Génère une clé secrète et un hash de mot de passe :
```bash
python -c "import secrets; print(secrets.token_urlsafe(48))"
python -c "from werkzeug.security import generate_password_hash; print(generate_password_hash('CHOISIS_UN_MOT_DE_PASSE_LONG'))"
```
Colle les valeurs dans `.env`. Modifie aussi `ADMIN_USERNAME`. Ne partage jamais `.env`.

Lance :
```bash
python app.py
```
Ouvre `http://127.0.0.1:5000`, puis connecte-toi sur `/admin/login`.

## Déploiement

Déploie sur un hébergeur compatible Python/WSGI avec HTTPS et une base persistante. Commande de démarrage :
```bash
gunicorn --workers 2 --bind 0.0.0.0:$PORT app:app
```
En production :
- définis `COOKIE_SECURE=1` derrière HTTPS ;
- utilise une `SECRET_KEY` longue et unique ;
- utilise PostgreSQL et un stockage de limitation partagé (Redis) si plusieurs instances ;
- configure sauvegardes, mises à jour et surveillance ;
- protège les variables d'environnement dans le panneau de l'hébergeur ;
- ne collecte que les données nécessaires et fixe une durée de conservation ;
- ajoute les coordonnées du responsable et une politique de confidentialité adaptée avant mise en ligne.

## Tests / limites

Le code est livré comme base de projet complète, mais il n'a pas été déployé sur un hébergeur ni testé dans ton environnement. Les notifications nécessitent un serveur SMTP configuré. Le compteur de visites compte les chargements de la page (pas des visiteurs uniques). SQLite convient à un prototype ou petit usage mono-instance ; PostgreSQL est préférable en production.

Ce projet n'est pas un avis juridique. Vérifie les obligations RGPD applicables à ton cas, notamment la base légale, l'information des personnes, les droits, les durées de conservation et les transferts éventuels.
