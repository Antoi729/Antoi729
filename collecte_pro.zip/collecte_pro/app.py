import csv
import io
import os
import secrets
from datetime import datetime, timezone
from functools import wraps

from dotenv import load_dotenv
from flask import Flask, abort, flash, make_response, redirect, render_template, request, session, url_for
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_sqlalchemy import SQLAlchemy
from flask_wtf.csrf import CSRFProtect
from werkzeug.security import check_password_hash, generate_password_hash

load_dotenv()

app = Flask(__name__)
app.config.update(
    SECRET_KEY=os.environ.get("SECRET_KEY", "CHANGE-ME-before-deployment"),
    SQLALCHEMY_DATABASE_URI=os.environ.get("DATABASE_URL", "sqlite:///collecte.db"),
    SQLALCHEMY_TRACK_MODIFICATIONS=False,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE", "0") == "1",
    MAX_CONTENT_LENGTH=1 * 1024 * 1024,
)
db = SQLAlchemy(app)
csrf = CSRFProtect(app)
limiter = Limiter(get_remote_address, app=app, default_limits=["200 per day", "50 per hour"],
                  storage_uri=os.environ.get("RATELIMIT_STORAGE_URI", "memory://"))

class Campaign(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False, default="Formulaire de contact")
    public_token = db.Column(db.String(64), unique=True, nullable=False, index=True)
    purpose = db.Column(db.String(500), nullable=False)
    recipient = db.Column(db.String(200), nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    visits = db.Column(db.Integer, default=0, nullable=False)
    active = db.Column(db.Boolean, default=True, nullable=False)

class Submission(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    campaign_id = db.Column(db.Integer, db.ForeignKey("campaign.id"), nullable=False, index=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(254), nullable=False)
    message = db.Column(db.String(2000), nullable=False)
    consent_at = db.Column(db.DateTime, nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)

def admin_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not session.get("admin"):
            return redirect(url_for("login", next=request.path))
        return fn(*args, **kwargs)
    return wrapped

def notify_admin(submission, campaign):
    # Optional SMTP notification. No personal data is included in the email.
    host = os.environ.get("SMTP_HOST")
    if not host:
        return
    import smtplib
    from email.message import EmailMessage
    msg = EmailMessage()
    msg["Subject"] = "Nouvelle réponse reçue"
    msg["From"] = os.environ["SMTP_FROM"]
    msg["To"] = os.environ["ADMIN_EMAIL"]
    msg.set_content(f"Une nouvelle réponse a été reçue pour « {campaign.title} » à {submission.created_at:%Y-%m-%d %H:%M UTC}. Connectez-vous au tableau de bord pour la consulter.")
    with smtplib.SMTP(host, int(os.environ.get("SMTP_PORT", "587")), timeout=10) as smtp:
        smtp.starttls()
        smtp.login(os.environ["SMTP_USER"], os.environ["SMTP_PASSWORD"])
        smtp.send_message(msg)

@app.route("/")
def index():
    if session.get("admin"):
        return redirect(url_for("dashboard"))
    return render_template("home.html")

@app.route("/c/<token>", methods=["GET", "POST"])
@limiter.limit("10 per minute", methods=["POST"])
def public_form(token):
    campaign = Campaign.query.filter_by(public_token=token, active=True).first_or_404()
    if request.method == "GET":
        campaign.visits += 1
        db.session.commit()
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip()
        message = request.form.get("message", "").strip()
        consent = request.form.get("consent")
        if not (name and email and message and consent == "yes"):
            flash("Tous les champs sont obligatoires, y compris le consentement.", "error")
            return render_template("public_form.html", campaign=campaign), 400
        if len(name) > 100 or len(email) > 254 or len(message) > 2000 or "@" not in email:
            flash("Certaines informations sont invalides ou trop longues.", "error")
            return render_template("public_form.html", campaign=campaign), 400
        sub = Submission(campaign_id=campaign.id, name=name, email=email, message=message,
                         consent_at=datetime.now(timezone.utc))
        db.session.add(sub)
        db.session.commit()
        try:
            notify_admin(sub, campaign)
        except Exception:
            app.logger.exception("Échec de notification SMTP")
        return render_template("thanks.html")
    return render_template("public_form.html", campaign=campaign)

@app.route("/admin/login", methods=["GET", "POST"])
@limiter.limit("5 per minute", methods=["POST"])
def login():
    if request.method == "POST":
        username = os.environ.get("ADMIN_USERNAME", "")
        password_hash = os.environ.get("ADMIN_PASSWORD_HASH", "")
        if request.form.get("username") == username and password_hash and check_password_hash(password_hash, request.form.get("password", "")):
            session.clear()
            session["admin"] = True
            return redirect(url_for("dashboard"))
        flash("Identifiants incorrects.", "error")
    return render_template("login.html")

@app.route("/admin/logout", methods=["POST"])
@admin_required
def logout():
    session.clear()
    return redirect(url_for("index"))

@app.route("/admin")
@admin_required
def dashboard():
    campaigns = Campaign.query.order_by(Campaign.created_at.desc()).all()
    total_submissions = Submission.query.count()
    total_visits = sum(c.visits for c in campaigns)
    return render_template("dashboard.html", campaigns=campaigns, total_submissions=total_submissions,
                           total_visits=total_visits)

@app.route("/admin/campaigns/new", methods=["GET", "POST"])
@admin_required
def new_campaign():
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        purpose = request.form.get("purpose", "").strip()
        recipient = request.form.get("recipient", "").strip()
        if not title or not purpose or not recipient or len(title) > 100 or len(purpose) > 500 or len(recipient) > 200:
            flash("Veuillez remplir les champs avec des longueurs valides.", "error")
            return render_template("new_campaign.html"), 400
        campaign = Campaign(title=title, purpose=purpose, recipient=recipient,
                            public_token=secrets.token_urlsafe(24))
        db.session.add(campaign)
        db.session.commit()
        flash("Lien créé. Partage-le uniquement avec une présentation claire de la collecte.", "success")
        return redirect(url_for("dashboard"))
    return render_template("new_campaign.html")

@app.route("/admin/campaign/<int:campaign_id>/toggle", methods=["POST"])
@admin_required
def toggle_campaign(campaign_id):
    campaign = Campaign.query.get_or_404(campaign_id)
    campaign.active = not campaign.active
    db.session.commit()
    return redirect(url_for("dashboard"))

@app.route("/admin/campaign/<int:campaign_id>/responses.csv")
@admin_required
def export_csv(campaign_id):
    campaign = Campaign.query.get_or_404(campaign_id)
    rows = Submission.query.filter_by(campaign_id=campaign.id).order_by(Submission.created_at.desc()).all()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["id", "nom", "email", "message", "consentement_utc", "date_utc"])
    for s in rows:
        writer.writerow([s.id, s.name, s.email, s.message, s.consent_at.isoformat(), s.created_at.isoformat()])
    response = make_response("\\ufeff" + output.getvalue())
    response.headers["Content-Type"] = "text/csv; charset=utf-8"
    response.headers["Content-Disposition"] = f'attachment; filename="reponses-campagne-{campaign.id}.csv"'
    return response

@app.route("/admin/submission/<int:submission_id>/delete", methods=["POST"])
@admin_required
def delete_submission(submission_id):
    sub = Submission.query.get_or_404(submission_id)
    campaign_id = sub.campaign_id
    db.session.delete(sub)
    db.session.commit()
    flash("Réponse supprimée.", "success")
    return redirect(url_for("responses", campaign_id=campaign_id))

@app.route("/admin/campaign/<int:campaign_id>/responses")
@admin_required
def responses(campaign_id):
    campaign = Campaign.query.get_or_404(campaign_id)
    submissions = Submission.query.filter_by(campaign_id=campaign.id).order_by(Submission.created_at.desc()).all()
    return render_template("responses.html", campaign=campaign, submissions=submissions)

@app.errorhandler(429)
def ratelimit_handler(e):
    return render_template("error.html", message="Trop de tentatives. Réessaie plus tard."), 429

@app.errorhandler(404)
def not_found(e):
    return render_template("error.html", message="Page introuvable."), 404

with app.app_context():
    db.create_all()

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", "5000")), debug=False)
